#ifndef LAST_NUMBER_FUNC_H
#define LAST_NUMBER_FUNC_H

#include <stdio.h>

int last_number_equal_x(FILE *f, double x);

#endif
