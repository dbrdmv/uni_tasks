#include "last_number_func.h"

int last_number_equal_x(FILE *f, double x)
{
    double current = 0.;
    int number = 0;
    int last_number = 0;

    while (fscanf(f, "%lf", &current) == 1)
    {
        number++;
        if (current == x)
            last_number = number;
    }
    return last_number;
}
