#include "last_number_func.h"

int main(void)
{
    FILE *f = fopen("input_data.txt", "r");
    double x = 0.;

    if (f == NULL)
    {
        printf("File error");
        return -1;
    }
    if (fscanf(f, "%lf", &x) != 1)
    {
        printf("File is empty");
        fclose(f);
        return -1;
    }

    printf("Answer: %d\n", last_number_equal_x(f, x));
    fclose(f);
    return 0;
}
